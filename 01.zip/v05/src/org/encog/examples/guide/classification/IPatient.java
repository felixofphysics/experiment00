package org.encog.examples.guide.classification;

public interface IPatient extends IResponder, ITableProducerReceptacle {
}