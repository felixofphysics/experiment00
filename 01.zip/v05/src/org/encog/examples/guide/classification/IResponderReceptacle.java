package org.encog.examples.guide.classification;

public interface IResponderReceptacle {
    public void connect(IResponder responder);
}