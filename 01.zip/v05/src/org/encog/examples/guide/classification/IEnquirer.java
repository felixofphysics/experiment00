package org.encog.examples.guide.classification;

public interface IEnquirer {
    public void startInterview();
}