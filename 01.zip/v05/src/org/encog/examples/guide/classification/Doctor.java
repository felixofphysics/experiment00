package org.encog.examples.guide.classification;

public class Doctor {
}
