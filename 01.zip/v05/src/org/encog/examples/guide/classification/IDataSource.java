package org.encog.examples.guide.classification;

public interface IDataSource {
    public String getDataSource();
    public void setDataSource(String dataSource);
}