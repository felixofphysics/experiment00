package org.encog.examples.guide.classification;

public interface ITableProducerReceptacle {
    public void connect(ITableProducer producer);
}