package org.encog.examples.guide.classification;

public interface IDataSet extends IDataSource, ITableProducer {
}