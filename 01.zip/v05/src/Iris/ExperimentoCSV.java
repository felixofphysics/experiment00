/*import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ExperimentoCSV {

    String content = new String(Files.readAllBytes(Paths.get(zombie)));

    IDataSet irisFile = new DataSetComponent();
    //irisFile.setDataSource("../src/zombie.csv");

    public static void main (String args[]){
        System.out.println("Oi");
    }
}
*/